import numpy as np
import matplotlib.pyplot as plt 

## w(c) = 1
def default(c):
  return 1

## L(C, 1 - C)
## Arguments: 
## x - x value space 
## X_test
## y_test
## pos_probs - Positive class probabilities
## w - weight function (w(c) = 1 by default)
def make_curve(y_true, p_pred, w=default, x=np.linspace(0.000,1.000,1001).tolist()):
  y_space = np.array([])
  n = len(p_pred)
  for c in x:
    sum = 0
    for i in range(0, n):
      pos_prob = p_pred[i]
      actual_class = y_true[i]
      if pos_prob > c and actual_class == 0:
        sum += c
      elif pos_prob <= c and actual_class == 1:
        sum += 1 - c
    l = w(c) * (sum / n)
    y_space = np.append(y_space, l)
  return y_space

## w(c) = 2
def brier(c):
  return 2

## w(c) = 1 / (c * (1-c))
def cross_entropy(c):
  return 1 / (c * (1-c))

# def save_curve(x, y_true, pos_probs, w=default, save=True, filename=None):
#   my_file = Path(f'{curves_path}{filename}')
#   if my_file.is_file():
#     with open(f'{curves_path}{filename}', 'r') as f:
#       return np.array(json.loads(f.read()))
#   else:
#     y = make_curve(x, y_true, pos_probs, w=w)
#     if save: 
#       with open(f'{curves_path}{filename}', 'w') as f:
#         f.write(json.dumps(list(y.tolist())))
#     return y