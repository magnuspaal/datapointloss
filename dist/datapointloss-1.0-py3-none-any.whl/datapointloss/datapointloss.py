import numpy as np
import matplotlib.pyplot as plt 

## w(c) = 1
def default(c):
  return 1

## L(C, 1 - C)
## Arguments: 
## x - x value space 
## X_test
## y_test
## pos_probs - Positive class probabilities
## w - weight function (w(c) = 1 by default)
def make_brier_curve(y_true, p_pred, w=default, x=np.linspace(0.000,1.000,1001).tolist()):
  y_space = np.array([])
  n = len(p_pred)
  for c in x:
    sum = 0
    for i in range(0, n):
      pos_prob = p_pred[i]
      actual_class = y_true[i]
      if pos_prob > c and actual_class == 0:
        sum += c
      elif pos_prob <= c and actual_class == 1:
        sum += 1 - c
    l = w(c) * (sum / n)
    y_space = np.append(y_space, l)
  return y_space

## w(c) = 2
def brier(c):
  return 2

## w(c) = 1 / (c * (1-c))
def cross_entropy(c):
  return 1 / (c * (1-c))

# def save_curve(x, y_true, pos_probs, w=default, save=True, filename=None):
#   my_file = Path(f'{curves_path}{filename}')
#   if my_file.is_file():
#     with open(f'{curves_path}{filename}', 'r') as f:
#       return np.array(json.loads(f.read()))
#   else:
#     y = make_curve(x, y_true, pos_probs, w=w)
#     if save: 
#       with open(f'{curves_path}{filename}', 'w') as f:
#         f.write(json.dumps(list(y.tolist())))
#     return y

def make_curve_areas(y_true, p_pred, x=np.linspace(0.000,1.000,1001).tolist(), n=None, w=default, label=None, plot_x=x, color_neg=None, color_pos=None):
  probs_0 = np.sort(p_pred[np.array(y_true) == 0])
  probs_1 = np.sort(p_pred[np.array(y_true) == 1])[::-1]

  n_neg = len(probs_0)
  n_pos = len(probs_1)

  if n == None:
    n = len(pos_probs)
  

  if label == 0 or label == None:
    for prob in probs_0:
      y = np.array([])
      for c in x:
        l = 0
        if prob > c:
          l = w(c) * (c / n) * n_neg
        y = np.append(y, l)
      n_neg -= 1
      #plt.plot(plot_x, y)
      if color_neg != None:
        plt.fill_between(plot_x, 0, y, color=color_neg)
      else:
        plt.fill_between(plot_x, 0, y)

  if label == 1 or label == None: 
    for prob in probs_1:
      y = np.array([])
      for c in x:
        l = 0
        if prob <= c:
          l = w(c) * ((1 - c) / n) * n_pos
        y = np.append(y, l)
      n_pos -= 1
      #plt.plot(plot_x, y)
      if color_pos != None:
        plt.fill_between(plot_x, 0, y, color=color_pos)
      else:
        plt.fill_between(plot_x, 0, y)

def make_loss_bins(x, y_test, pos_probs, n=None, w=default, label=0, bins=100):
  
  prrobs = []
  if label == 0:
    probs = np.sort(pos_probs[np.array(y_test) == 0])
  elif label == 1:
    probs = np.sort(pos_probs[np.array(y_test) == 1])[::-1]

  n_label = len(probs)

  if n == None:
    n = len(pos_probs)
  
  f = lambda c : (1 / n) * np.sum(
      (1 if pred > c else 0) * (1 - label) * c +
      (0 if pred > c else 1) * label * (1 - c))
  
  losses = []

  for i in range(len(probs)):
    pred = probs[i]
    y, err = integrate.quad(f, 0, 1)
    losses.append([y])

  plt.figure(figsize=(20,10))

  probs_list = []
  for i in range(len(probs)):
    probs_list.append([probs[i]])

  plt.hist(probs_list, weights=losses, bins=bins, histtype='stepfilled', stacked=True)

  plt.xlabel('Probability of positive class', fontsize=18)
  plt.ylabel('Total loss', fontsize=18)

  plt.xticks(fontsize=18)
  plt.yticks(fontsize=18)

  plt.xlim([0, 1])

  plt.show()